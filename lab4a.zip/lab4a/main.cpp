#include <iostream>
#include<string>
#include "Tosoba3.h"
using namespace std;

int main()
{
    /*Tosoba3 osoba("Martyniuk");
    cout<<osoba.getNazwisko()<<endl;*/

    string ja ("Martyniuk");
    cout<<"adres ja: "<<&ja<<endl;
    Tosoba3 osoba(ja);
    cout<<"adres os1: "<<&osoba<<endl;
    cout<<osoba.getNazwisko()<<endl;
    return 0;
}
