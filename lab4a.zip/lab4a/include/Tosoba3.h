#ifndef TOSOBA3_H
#define TOSOBA3_H
#include<string>
using namespace std;

class Tosoba3
{
    public:
        Tosoba3();
        virtual ~Tosoba3();
        //Tosoba3(string naz); //pracujemy na kopii
        //Tosoba3(string *naz);
        Tosoba3(const string &naz);
        string getNazwisko();
    protected:

    private:
        string nazwisko;
};

#endif // TOSOBA3_H
