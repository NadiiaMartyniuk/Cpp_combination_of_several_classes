#include "Tosoba3.h"
#include<string>
#include <iostream>
using namespace std;
Tosoba3::Tosoba3()
{
    //ctor
}

Tosoba3::~Tosoba3()
{
    //dtor
}

Tosoba3::Tosoba3(const string &naz){
    cout<<"Adres parametru naz: "<<&naz<<endl;
//    naz="Kowalski";
    nazwisko=naz;
}
string Tosoba3::getNazwisko(){
    return nazwisko;
}
