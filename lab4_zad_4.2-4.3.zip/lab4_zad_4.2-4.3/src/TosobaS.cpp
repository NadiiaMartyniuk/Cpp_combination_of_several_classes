#include "TosobaS.h"
#include <iostream>
#include<string>
using namespace std;
int TosobaS::liczbaObiektow=0;
string TosobaS::kraj="Ukraina";
TosobaS::TosobaS()
{
    imie="Nadiia";
    nazwisko="Martyniuk";
    wiek=18;
    liczbaObiektow++;
    cout<<"Dodalem osobe ";
}
TosobaS::TosobaS(string nazwisko, string imie, int wiek){
    this->nazwisko=nazwisko;
    this->imie=imie;
    this->wiek=wiek;
    liczbaObiektow++;
    cout<<"Dodalem osobe ";
}

TosobaS::~TosobaS()
{
    liczbaObiektow--;
    cout<<"Zabralem osobe ";
}
TosobaS::TosobaS(TosobaS &osoba){
    imie=osoba.imie;
    nazwisko=osoba.nazwisko;
    wiek=osoba.wiek;
    liczbaObiektow++;
    cout<<"Dodalem osobe ";
}

//Konieczna redefinicja ststycznych pol
//z ewentualna inicjalizacja

int TosobaS::ile(){
    return liczbaObiektow;
}
string TosobaS::GetKraj(){
    return kraj;
}
void TosobaS::podajDane(){
    cout<<"Imie oraz nazwisko ";
    cin>>imie>>nazwisko;
    cout<<"Wiek: ";
    cin>>wiek;
}
void TosobaS::wyswietl(){
    cout<<imie<<" "<<nazwisko<<" "<<wiek<<" "<<kraj<<endl;
}

