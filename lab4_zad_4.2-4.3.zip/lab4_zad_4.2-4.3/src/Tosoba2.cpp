#include "Tdata.h"
#include "Tosoba2.h"
#include <iostream>
#include<iomanip>
#include<string>

using namespace std;

Tosoba2::Tosoba2()
{
    //ctor
}

Tosoba2::~Tosoba2()
{
    //dtor
}
void Tosoba2::Wczytaj(){
    cout<<"Podaj imie oraz nazwisko ";
    cin>>imie>>nazwisko;
    /*cout<<"Podaj motto ";
    cin.ignore();
    getline(cin,motto);*/
    dataUr.Wczytaj();
}
void Tosoba2::Wyswietl(){
    cout<<left<<setfill(' ')<<setw(10)<<imie<<" "<<setw(15)<<nazwisko<<" ";
    dataUr.Wyswietl();
}
string Tosoba2::GetNazwiskoImie(){
    return nazwisko+" "+imie;
}
int Tosoba2::roznicaWieku(Tosoba2 &partner){
    return abs(dataUr.GetR()-partner.dataUr.GetR());
}
Tosoba2 Tosoba2::dluzszeNazwisko(Tosoba2 &partner){
    if((nazwisko.length())>(partner.nazwisko.length())){
        return *this;
    }
    return partner;
}
