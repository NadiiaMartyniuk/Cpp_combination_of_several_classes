#ifndef TOSOBAS_H
#define TOSOBAS_H
#include<string>
using namespace std;
const int DL=20;
class TosobaS
{
    public:
        TosobaS();
        TosobaS(string nazwisko, string imie, int wiek);
        TosobaS(TosobaS &osoba);
        virtual ~TosobaS();
        void podajDane();
        void wyswietl();
        static int ile();
        static string GetKraj();
    protected:
        string nazwisko, imie;
        int wiek;
        static string kraj;

    private:
        static int liczbaObiektow;
};

#endif // TOSOBAS_H
