#ifndef TDATA_H
#define TDATA_H
#include <iostream>
using namespace std;

class Tdata
{
    public:
        Tdata();
        Tdata(int dd, int mm, int rr):d(dd),m(mm),r(rr){
            //cout<<"Konstruktor z parametrami clasy Tdata"<<endl;
        };
        virtual ~Tdata();
        void Wczytaj();
        void Wyswietl();
        int GetR();

    protected:

    private:
        int d;
        int m;
        int r;
};

#endif // TDATA_H
