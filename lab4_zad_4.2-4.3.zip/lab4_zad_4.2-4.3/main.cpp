#include <iostream>
#include<string>
#include "Tdata.h"
#include "Tosoba2.h"
#include "TosobaS.h"
using namespace std;

int main()
{
    //TosobaS osoba;
    cout<<"Liczba obiektow: "<<TosobaS::ile()<<endl;
    TosobaS os1;
    cout<<"Liczba obiektow: "<<os1.ile()<<endl;
    TosobaS os2("Mudryk", "Olcha", 17);
    cout<<"Liczba obiektow: "<<os2.ile()<<endl;
    cout<<endl<<"Przecodzimy w wewneczny blok"<<endl;
    {
        //obiekt w wewnecznym bloku
        TosobaS os3;
        cout<<"Liczba obiektow: "<<os1.ile()<<endl;
    }
    cout<<"Wychodzimy z wewnecznego bloku"<<endl;
    cout<<"Liczba obiektow: "<<os1.ile()<<endl;

    //obiect za pomoca wskaznika
    cout<<endl<<"Wskaznik "<<endl;
    TosobaS* os4 = new TosobaS;
    cout<<"Liczba obiektow: "<<TosobaS::ile()<<endl;

    //obiect za pomoca referencji
    cout<<endl<<"Referencja "<<endl;
    TosobaS &osoba5=os1;
    cout<<"Liczba obiektow: "<<TosobaS::ile()<<endl;

    //kopiowanie obiectow
    cout<<endl<<"Kopiwanie "<<endl;
    TosobaS osoba6=os2;
    cout<<"Liczba obiektow: "<<TosobaS::ile()<<endl;

    cout<<endl<<"TWORZYMY TABLICU OSOB (Obiekty)"<<endl;
    const int n=5;
    Tosoba2 tab_obiekow[n];
    for (int i=0; i<n; i++)
        tab_obiekow[i].Wczytaj();
    for (int i=0; i<n; i++)
        tab_obiekow[i].Wyswietl();

    cout<<endl<<"TWORZYMY TABLICU OSOB (Wskazniki)"<<endl;
    Tosoba2 *tab_wskaznikow[n];
    for (int i=0; i<n; i++){
        tab_wskaznikow[i]=new Tosoba2;
        tab_wskaznikow[i]->Wczytaj();
    }
    for (int i=0; i<n; i++){
        tab_wskaznikow[i]->Wyswietl();
    }

    return 0;
}
