#include <iostream>
#include "Tdata.h"
#include "Tosoba2.h"
#include<string>
using namespace std;

int main()
{
    Tosoba2 osoba;
    osoba.Wczytaj();
    osoba.Wyswietl();

    Tosoba2 partner;
    partner.Wczytaj();
    partner.Wyswietl();

    cout<<endl;
    cout<<"Imie oraz nazwisko osoby: "<<osoba.GetNazwiskoImie()<<endl;
    cout<<"Imie oraz nazwisko partnera: "<<partner.GetNazwiskoImie()<<endl;
    cout<<"Roznica wieku "<<osoba.roznicaWieku(partner)<<endl;
    cout<<"Dluzsze nazwislo ma "<<osoba.dluzszeNazwisko(partner).GetNazwiskoImie()<<endl;
    return 0;
}
