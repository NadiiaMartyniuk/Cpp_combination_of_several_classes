#include "Tdata.h"
#include <iostream>
#include<iomanip>
using namespace std;
Tdata::Tdata()
{
    cout<<"Konstruktor domyslny clasy Tdata"<<endl;
}

Tdata::~Tdata()
{
    cout<<"Destruktor clasy Tdata"<<endl;
}

void Tdata::Wczytaj(){
    cout<<"Podaj dzien, miesiac, rok ";
    cin>>this->d>>this->m>>this->r;
}
void Tdata::Wyswietl(){
    cout<<"Data: "<<setfill('0')<<setw(2)<<this->d<<"."<<setw(2)<<this->m<<"."<<this->r<<endl;
}
int Tdata::GetR(){
    return this->r;
}
