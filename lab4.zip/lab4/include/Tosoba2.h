#ifndef TOSOBA2_H
#define TOSOBA2_H
#include<string>
#include "Tdata.h"

class Tosoba2
{
    public:
        Tosoba2();
        Tosoba2(const std::string & nazwisko, const std::string &imie, const Tdata & d):nazwisko(nazwisko),imie(imie),dataUr(d){};
        virtual ~Tosoba2();
        void Wczytaj();
        void Wyswietl();
        string GetNazwiskoImie();
        int roznicaWieku(Tosoba2 & partner);
        Tosoba2 dluzszeNazwisko(Tosoba2 &partner);
    protected:

    private:
        string nazwisko;
        string imie;
        string motto;
        Tdata dataUr;
};

#endif // TOSOBA2_H
